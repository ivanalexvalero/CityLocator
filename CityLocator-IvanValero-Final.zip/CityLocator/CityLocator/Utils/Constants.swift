//
//  Constants.swift
//  CityLocator
//
//  Created by Ivan Alexander Valero on 31/07/2024.
//

import Foundation

struct Constants {
    static let baseURL = "https://gist.githubusercontent.com"
}
